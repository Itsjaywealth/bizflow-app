import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const nav = [
  { path: '/', icon: '📊', label: 'Dashboard' },
  { path: '/invoices', icon: '🧾', label: 'Invoices' },
  { path: '/clients', icon: '🤝', label: 'Clients' },
  { path: '/staff', icon: '👥', label: 'My Team' },
]

export default function Layout({ children, session, business }) {
  const { pathname } = useLocation()
  const [menuOpen, setMenuOpen] = useState(false)

  async function signOut() {
    await supabase.auth.signOut()
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {/* Sidebar */}
      <aside style={{ width: 240, background: '#0a1628', display: 'flex', flexDirection: 'column', position: 'fixed', top: 0, left: 0, height: '100vh', zIndex: 50, transition: 'transform .3s', transform: menuOpen ? 'translateX(0)' : undefined }}>
        <div style={{ padding: '24px 20px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 36, height: 36, background: '#0d7c4f', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M3 3h7v7H3zm0 11h7v7H3zm11-11h7v7h-7zm0 11h7v7h-7z"/></svg>
            </div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 800, color: 'white' }}>BizFlow <span style={{ color: '#34d399' }}>NG</span></div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 1 }}>{business?.name || 'My Business'}</div>
            </div>
          </div>
        </div>

        <nav style={{ flex: 1, padding: '16px 12px' }}>
          {nav.map(item => {
            const active = pathname === item.path
            return (
              <Link key={item.path} to={item.path} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 12px', borderRadius: 10, marginBottom: 4, textDecoration: 'none', background: active ? 'rgba(13,124,79,0.25)' : 'transparent', color: active ? '#34d399' : 'rgba(255,255,255,0.6)', fontWeight: active ? 700 : 500, fontSize: 14, transition: 'all .2s', borderLeft: active ? '3px solid #0d7c4f' : '3px solid transparent' }}
                onClick={() => setMenuOpen(false)}>
                <span style={{ fontSize: 18 }}>{item.icon}</span>
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div style={{ padding: '16px 12px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', padding: '0 12px', marginBottom: 8 }}>
            {session?.user?.email}
          </div>
          <button onClick={signOut} style={{ width: '100%', background: 'rgba(255,255,255,0.06)', color: 'rgba(255,255,255,0.6)', border: 'none', padding: '10px 12px', borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span>🚪</span> Sign Out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, marginLeft: 240, padding: 28, maxWidth: '100%' }}>
        {/* Mobile header */}
        <div style={{ display: 'none' }} className="mobile-header">
          <button onClick={() => setMenuOpen(!menuOpen)}>☰</button>
        </div>

        {children}
      </main>

      <style>{`
        @media(max-width:768px){
          aside { transform: translateX(-100%); }
          main { margin-left: 0 !important; padding: 16px !important; }
        }
      `}</style>
    </div>
  )
}
